---
language:
- en
license: other
task_categories:
- question-answering
- text-generation
tags:
- retail
- sales
- supermarket
- tabular-to-text
- synthetic
size_categories:
- 1K<n<10K
configs:
- config_name: default
  data_files:
  - split: train
    path: data/train-*
  - split: validation
    path: data/validation-*
  - split: test
    path: data/test-*
---

# Supermarket Sales Q&A

Question–answer pairs generated from a 15,000-row supermarket sales table (3 branches in Myanmar:
A = Yangon, B = Mandalay, C = Naypyitaw; January–March 2019). It was built to fine-tune small
language models (e.g. SmolLM2-135M) for retail analytics questions.

## Splits

| split      | rows  |
|------------|------:|
| train      | 5,180 |
| validation |   790 |
| test       |   790 |

## Fields

| field      | description |
|------------|-------------|
| `id`       | row id (`train_00000`, …) |
| `question` | natural-language question |
| `answer`   | reference answer computed from the sales table |
| `category` | `calculation`, `overview`, `breakdown`, `ranking`, `cross`, `cross_value`, `pricing`, `time`, `concept` |
| `fact_id`  | `fact_XXXX` for aggregate/concept facts, `inv_<invoice id>` for calculation rows |

## How it was built

* **Aggregate facts**: totals, counts, average ratings and units sold, broken down by branch, city, product line,
  payment method, gender, customer type, month, weekday and pairs of these. Each fact has 4 paraphrased
  questions: 2 are in train, 1 in validation and 1 in test. Validation and test therefore measure whether
  the model recalls the same facts from **wording it has not seen**.
* **Calculations**: 6,000 invoices are sampled, and each is asked as "quantity × unit price → COGS, 5% tax, total".
  These are split **by invoice** (4,800 / 600 / 600), so no transaction appears in more than one split.
* **Concepts**: definitions of the table's columns (COGS, tax, gross income, the constant 4.76% gross margin, etc.).

## Caveats

* Rows 1–1000 of the source table match the public Kaggle "Supermarket Sales" dataset. The remaining 14,000 rows
  are synthetic additions. Check the original dataset's license before commercial use.
* In the source data, `gross income` always equals the 5% tax and the gross margin is a constant 4.7619%.
  Margin-related answers reflect this.
* No research-paper text is included. Only content derived from the CSV is published here.
