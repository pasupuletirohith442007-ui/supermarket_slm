"""Upload the train / validation / test splits to the Hugging Face Hub.

  .venv/bin/hf auth login            # once, with a WRITE token
  .venv/bin/python scripts/upload_dataset.py <username>/<dataset-name> [--private]

Only CSV-derived files are uploaded (data/train.csv, validation.csv, test.csv + DATASET_CARD.md).
data/papers_corpus.jsonl is copyrighted paper text and is never uploaded.
"""
import argparse
from pathlib import Path

from datasets import DatasetDict, load_dataset
from huggingface_hub import HfApi

ROOT = Path(__file__).resolve().parent.parent
ap = argparse.ArgumentParser()
ap.add_argument("repo_id")
ap.add_argument("--private", action="store_true")
args = ap.parse_args()

files = {s: str(ROOT / "data" / f"{s}.csv") for s in ["train", "validation", "test"]}
ds = load_dataset("csv", data_files=files)
ds = DatasetDict({s: ds[s] for s in ["train", "validation", "test"]})  # keep this order
print(ds)

ds.push_to_hub(args.repo_id, private=args.private)
HfApi().upload_file(path_or_fileobj=str(ROOT / "data" / "DATASET_CARD.md"), path_in_repo="README.md",
                    repo_id=args.repo_id, repo_type="dataset")
print(f"done: https://huggingface.co/datasets/{args.repo_id}")
