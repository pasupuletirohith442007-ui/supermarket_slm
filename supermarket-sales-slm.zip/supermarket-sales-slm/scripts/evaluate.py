"""Evaluate the fine-tuned model on the test split.

  .venv/bin/python scripts/evaluate.py [--model models/smollm2-135m-supermarket] [--n 300]

Metric: numeric accuracy = fraction of test answers where every number in the reference
answer also appears in the generated answer (formatting like $ and commas ignored).
Also reports the same metric for the untouched base model for comparison.
"""
import argparse
import csv
import json
import random
import re
from collections import defaultdict
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

ROOT = Path(__file__).resolve().parent.parent
SYSTEM = "You are a retail analytics assistant for a supermarket chain with branches in Yangon, Mandalay and Naypyitaw."
ap = argparse.ArgumentParser()
ap.add_argument("--model", default=str(ROOT / "models" / "smollm2-135m-supermarket"))
ap.add_argument("--n", type=int, default=300)
ap.add_argument("--base", action="store_true", help="also score the base model")
args = ap.parse_args()
torch.set_num_threads(16)

test = list(csv.DictReader(open(ROOT / "data" / "test.csv", newline="", encoding="utf-8")))
random.Random(0).shuffle(test)
test = test[: args.n]
NUM = re.compile(r"\d[\d,]*\.?\d*")


def nums(s):
    return {x.replace(",", "").rstrip(".") for x in NUM.findall(s)}


def run(path):
    tok = AutoTokenizer.from_pretrained(path)
    model = AutoModelForCausalLM.from_pretrained(path).eval()
    hits, by_cat, samples = 0, defaultdict(lambda: [0, 0]), []
    for ex in test:
        prompt = tok.apply_chat_template(
            [{"role": "system", "content": SYSTEM}, {"role": "user", "content": ex["question"]}],
            tokenize=False, add_generation_prompt=True)
        ids = tok(prompt, return_tensors="pt", add_special_tokens=False)
        with torch.no_grad():
            out = model.generate(**ids, max_new_tokens=160, do_sample=False)
        pred = tok.decode(out[0, ids.input_ids.shape[1]:], skip_special_tokens=True).strip()
        ok = nums(ex["answer"]) <= nums(pred)
        hits += ok
        by_cat[ex["category"]][0] += ok
        by_cat[ex["category"]][1] += 1
        if len(samples) < 8:
            samples.append((ex["question"], ex["answer"], pred, ok))
    print(f"\n### {path}\nnumeric accuracy: {hits}/{len(test)} = {hits/len(test):.1%}")
    for c, (h, t) in sorted(by_cat.items()):
        print(f"  {c:12s} {h}/{t} = {h/t:.1%}")
    for q, a, p, ok in samples:
        print(f"\nQ: {q}\nREF: {a}\nGEN: {p}\n{'✓' if ok else '✗'}")
    return hits / len(test)


if args.base:
    run("HuggingFaceTB/SmolLM2-135M-Instruct")
run(args.model)
