"""Build a Q&A dataset (train/validation/test) from supermarket_sales_15000.csv.

Outputs (in data/):
  train/validation/test .jsonl and .csv       -> public, CSV-derived only
  papers_corpus.jsonl                          -> local only (copyrighted paper text, deduplicated + cleaned)

Split strategy
  * calculation questions: split by Invoice ID (80/10/10) so no transaction appears in two splits
  * aggregate-fact & concept questions: every fact has several paraphrases; paraphrases are
    distributed so validation/test ask about the same facts with *unseen wording*
"""
import hashlib
import json
import random
import re
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "data"
OUT.mkdir(exist_ok=True)
rng = random.Random(42)

# --------------------------------------------------------------------------- load
df = pd.read_csv(ROOT / "supermarket_sales_15000.csv")
df["Date"] = pd.to_datetime(df["Date"], format="mixed", dayfirst=False)
df["Month"] = df["Date"].dt.month_name()
df["Weekday"] = df["Date"].dt.day_name()
df["Hour"] = df["Time"].str.slice(0, 2).astype(int)


def money(x):
    return f"${x:,.2f}"


facts = []  # each: dict(category, questions=[...], answer)


def fact(category, questions, answer):
    facts.append({"category": category, "questions": questions, "answer": answer})


# --------------------------------------------------------------------------- overall
n = len(df)
fact("overview", [
    "How many transactions are in the supermarket sales dataset?",
    "What is the total number of sales records?",
    "How many invoices does the dataset contain?",
    "Count the transactions in the supermarket data.",
], f"The dataset contains {n:,} transactions, recorded between "
   f"{df.Date.min():%d %B %Y} and {df.Date.max():%d %B %Y}.")

fact("overview", [
    "What is the total revenue across all branches?",
    "How much did the supermarket sell in total (including tax)?",
    "What are the overall total sales?",
    "Give me the grand total of sales.",
], f"Total sales including 5% tax are {money(df.Total.sum())} across {n:,} transactions.")

fact("overview", [
    "What is the average transaction value?",
    "How much does a customer spend per invoice on average?",
    "What is the mean basket value?",
    "On average, what is the total of one sale?",
], f"The average transaction total is {money(df.Total.mean())} "
   f"(median {money(df.Total.median())}).")

fact("overview", [
    "How many items are bought per transaction on average?",
    "What is the average quantity per sale?",
    "What is the mean number of units in a purchase?",
    "Typically how many units does a customer buy?",
], f"Customers buy {df.Quantity.mean():.2f} units per transaction on average "
   f"(range {df.Quantity.min()}–{df.Quantity.max()}).")

fact("overview", [
    "What is the average customer rating?",
    "How satisfied are customers on average?",
    "What is the mean rating score?",
    "What rating do customers give on average?",
], f"The average customer rating is {df.Rating.mean():.2f} out of 10 "
   f"(lowest {df.Rating.min()}, highest {df.Rating.max()}).")

fact("overview", [
    "How much tax was collected in total?",
    "What is the total 5% tax amount?",
    "Sum of all tax collected?",
    "How much VAT/tax did the store charge overall?",
], f"Total 5% tax collected is {money(df['Tax 5%'].sum())}.")

fact("overview", [
    "What is the total gross income?",
    "How much gross income did the supermarket earn?",
    "What is total gross profit in the dataset?",
    "Total gross income across all sales?",
], f"Total gross income is {money(df['gross income'].sum())}. In this dataset gross income "
   f"equals the 5% tax amount on every invoice.")

# --------------------------------------------------------------------------- single-dimension breakdowns
DIMS = {
    "Branch": ("branch", "branches"),
    "City": ("city", "cities"),
    "Product line": ("product line", "product lines"),
    "Payment": ("payment method", "payment methods"),
    "Gender": ("gender", "genders"),
    "Customer type": ("customer type", "customer types"),
    "Month": ("month", "months"),
    "Weekday": ("day of the week", "days of the week"),
}

for col, (one, many) in DIMS.items():
    g = df.groupby(col)
    rev = g.Total.sum().sort_values(ascending=False)
    cnt = g.size().sort_values(ascending=False)
    rat = g.Rating.mean().sort_values(ascending=False)
    qty = g.Quantity.sum().sort_values(ascending=False)

    listing = "; ".join(f"{k}: {money(v)}" for k, v in rev.items())
    fact("breakdown", [
        f"What is the total revenue by {one}?",
        f"Break down sales by {one}.",
        f"How much did each of the {many} sell?",
        f"Show total sales per {one}.",
    ], f"Total sales by {one}: {listing}.")

    fact("ranking", [
        f"Which {one} has the highest sales?",
        f"Which {one} generates the most revenue?",
        f"What is the top {one} by total sales?",
        f"Name the best-selling {one}.",
    ], f"{rev.index[0]} has the highest total sales at {money(rev.iloc[0])}, "
       f"followed by {rev.index[1]} ({money(rev.iloc[1])}).")

    fact("ranking", [
        f"Which {one} has the lowest sales?",
        f"Which {one} generates the least revenue?",
        f"What is the weakest {one} by total sales?",
        f"Which {one} sells the least?",
    ], f"{rev.index[-1]} has the lowest total sales at {money(rev.iloc[-1])}.")

    listing = "; ".join(f"{k}: {v:,}" for k, v in cnt.items())
    fact("breakdown", [
        f"How many transactions are there per {one}?",
        f"What is the number of sales for each {one}?",
        f"Count invoices by {one}.",
        f"How are transactions distributed across {many}?",
    ], f"Transactions by {one}: {listing}.")

    listing = "; ".join(f"{k}: {v:.2f}" for k, v in rat.items())
    fact("breakdown", [
        f"What is the average rating by {one}?",
        f"How do customer ratings compare across {many}?",
        f"Which {one} has the best customer rating?",
        f"Show mean rating per {one}.",
    ], f"Average rating by {one}: {listing}. {rat.index[0]} is rated highest.")

    listing = "; ".join(f"{k}: {v:,}" for k, v in qty.items())
    fact("breakdown", [
        f"How many units were sold per {one}?",
        f"What is total quantity sold by {one}?",
        f"Which {one} sells the most units?",
        f"Show quantity sold for each {one}.",
    ], f"Units sold by {one}: {listing}.")

# branch <-> city mapping
mapping = df.groupby("Branch").City.first()
for b, c in mapping.items():
    fact("overview", [
        f"Which city is branch {b} in?",
        f"Where is branch {b} located?",
        f"What city does branch {b} serve?",
        f"Branch {b} belongs to which city?",
    ], f"Branch {b} is located in {c}.")

# --------------------------------------------------------------------------- two-dimension facts
PAIRS = [("Branch", "Product line"), ("Branch", "Payment"), ("Gender", "Product line"),
         ("Customer type", "Payment"), ("Branch", "Month"), ("Customer type", "Product line"),
         ("Gender", "Payment"), ("City", "Customer type")]
LABEL = {"Branch": lambda v: f"branch {v}", "Gender": lambda v: f"{v.lower()} customers",
         "Customer type": lambda v: f"{v} customers", "Month": lambda v: v, "City": lambda v: v}
for a, b in PAIRS:
    one_a, one_b = DIMS[a][0], DIMS[b][0]
    for va_raw, sub in df.groupby(a):
        va = LABEL[a](va_raw)
        rev = sub.groupby(b).Total.sum().sort_values(ascending=False)
        cnt = sub.groupby(b).size().sort_values(ascending=False)
        listing = "; ".join(f"{k}: {money(v)}" for k, v in rev.items())
        fact("cross", [
            f"For {va}, what are total sales by {one_b}?",
            f"Break down {va} sales by {one_b}.",
            f"In {va}, how much revenue does each {one_b} bring in?",
            f"Show {one_b} revenue for {va}.",
        ], f"Sales for {va} by {one_b}: {listing}.")
        fact("cross", [
            f"Which {one_b} is most popular for {va}?",
            f"What is the most common {one_b} among {va} sales?",
            f"For {va}, which {one_b} has the most transactions?",
            f"Most frequent {one_b} in {va}?",
        ], f"For {va}, the most frequent {one_b} is {cnt.index[0]} with {cnt.iloc[0]:,} "
           f"transactions (least: {cnt.index[-1]}, {cnt.iloc[-1]:,}).")
        for vb, v in rev.items():
            fact("cross_value", [
                f"What are total sales of {vb} in {va}?",
                f"How much revenue did {vb} generate for {va}?",
                f"Total {vb} sales for {va}?",
                f"Revenue from {vb} within {va}?",
            ], f"Total sales of {vb} for {va} are {money(v)} "
               f"from {int((sub[b] == vb).sum()):,} transactions.")

# --------------------------------------------------------------------------- price / time facts
up = df.groupby("Product line")["Unit price"].mean().sort_values(ascending=False)
fact("pricing", [
    "What is the average unit price per product line?",
    "Which product line has the most expensive items on average?",
    "Compare unit prices across product lines.",
    "Show mean unit price by product line.",
], "Average unit price by product line: " + "; ".join(f"{k}: {money(v)}" for k, v in up.items()) + ".")
fact("pricing", [
    "What is the price range of products?",
    "What are the minimum and maximum unit prices?",
    "How cheap and how expensive are items?",
    "Give the unit price range.",
], f"Unit prices range from {money(df['Unit price'].min())} to {money(df['Unit price'].max())}, "
   f"averaging {money(df['Unit price'].mean())}.")

hr = df.groupby("Hour").Total.sum().sort_values(ascending=False)
fact("time", [
    "What is the busiest hour for sales?",
    "At what time of day is revenue highest?",
    "Which hour has the most sales?",
    "Peak sales hour?",
], f"The highest-revenue hour starts at {hr.index[0]}:00 ({money(hr.iloc[0])}); "
   f"the store trades from 10:00 to 21:00.")
fact("time", [
    "What are the store's trading hours?",
    "When does the supermarket open and close?",
    "Between which hours do sales happen?",
    "What time range do transactions cover?",
], f"Transactions occur between {df.Time.min()} and {df.Time.max()}.")

# --------------------------------------------------------------------------- concepts (original explanations)
CONCEPTS = [
    (["What is COGS in this dataset?", "Define cogs.", "How is cost of goods sold computed here?",
      "What does the cogs column mean?"],
     "COGS (cost of goods sold) is Unit price × Quantity, i.e. the value of goods before tax."),
    (["How is the 5% tax calculated?", "What is the Tax 5% column?", "How do I compute tax on a sale?",
      "Explain the tax calculation."],
     "Tax 5% = 0.05 × COGS = 0.05 × Unit price × Quantity."),
    (["How is the Total column calculated?", "What does Total mean?", "How do you get the invoice total?",
      "Explain how the total is computed."],
     "Total = COGS + Tax 5% = 1.05 × Unit price × Quantity."),
    (["What is gross income in this dataset?", "Define gross income.", "How is gross income calculated?",
      "What does the gross income column represent?"],
     "Gross income = Total − COGS. Because Total is COGS plus 5% tax, gross income equals the tax amount."),
    (["Why is the gross margin percentage always 4.76%?", "What is gross margin percentage here?",
      "Explain the 4.761904762 value.", "Why doesn't gross margin vary?"],
     "Gross margin % = gross income / Total × 100 = 0.05 / 1.05 × 100 ≈ 4.7619%. It is constant because "
     "gross income is always 5% of COGS, so margin analysis on this dataset is not informative."),
    (["What is the difference between Member and Normal customers?", "What does customer type mean?",
      "Explain customer types.", "What are the customer type categories?"],
     "Customer type is Member (loyalty card holder) or Normal (no membership). "
     f"Members account for {(df['Customer type']=='Member').mean()*100:.1f}% of transactions."),
    (["What payment methods are accepted?", "Which payment options exist?", "How can customers pay?",
      "List the payment methods."],
     "Customers pay by Ewallet, Cash or Credit card."),
    (["What product lines does the supermarket sell?", "List the product categories.",
      "Which product lines are in the data?", "What categories of goods are sold?"],
     "The six product lines are: " + ", ".join(sorted(df["Product line"].unique())) + "."),
    (["What does the Rating column measure?", "What is rating?", "How are customers' ratings scaled?",
      "Explain the rating field."],
     "Rating is the customer's satisfaction score for the shopping experience on a scale from 1 to 10."),
    (["What is average transaction value and how do I compute it?", "How to calculate average basket size?",
      "Define average transaction value.", "How is mean sale value computed?"],
     "Average transaction value = sum of Total / number of transactions."),
]
for qs, a in CONCEPTS:
    fact("concept", qs, a)

# --------------------------------------------------------------------------- split facts by paraphrase
rows = {"train": [], "validation": [], "test": []}
for i, f in enumerate(facts):
    qs = f["questions"][:]
    rng.shuffle(qs)
    assign = ["train", "train", "validation", "test"]
    for q, split in zip(qs, assign):
        rows[split].append({"question": q, "answer": f["answer"], "category": f["category"],
                            "fact_id": f"fact_{i:04d}"})

# --------------------------------------------------------------------------- calculation questions split by invoice
CALC_TEMPLATES = [
    "A customer buys {q} items at {p} each. What are the COGS, 5% tax and total?",
    "Calculate the invoice total for {q} units priced at {p}.",
    "What is the 5% tax on a purchase of {q} items costing {p} each?",
    "If the unit price is {p} and quantity is {q}, what is the total including tax?",
]
inv = df.sample(n=6000, random_state=42).reset_index(drop=True)
for idx, r in inv.iterrows():
    split = "train" if idx < 4800 else ("validation" if idx < 5400 else "test")
    p, q = r["Unit price"], int(r["Quantity"])
    cogs = round(p * q, 2)
    tax = round(cogs * 0.05, 4)
    total = round(cogs + tax, 4)
    question = rng.choice(CALC_TEMPLATES).format(q=q, p=money(p)).replace("1 items", "1 item").replace("1 units", "1 unit")
    answer = (f"COGS = {q} × {money(p)} = {money(cogs)}. Tax = 5% × {money(cogs)} = ${tax:,.2f}. "
              f"Total = {money(cogs)} + ${tax:,.2f} = ${total:,.2f}.")
    rows[split].append({"question": question, "answer": answer, "category": "calculation",
                        "fact_id": f"inv_{r['Invoice ID']}"})

for split, items in rows.items():
    rng.shuffle(items)
    for j, it in enumerate(items):
        it["id"] = f"{split}_{j:05d}"
    with open(OUT / f"{split}.jsonl", "w") as fh:
        for it in items:
            fh.write(json.dumps({k: it[k] for k in ["id", "question", "answer", "category", "fact_id"]},
                                ensure_ascii=False) + "\n")
    pd.DataFrame(items)[["id", "question", "answer", "category", "fact_id"]].to_csv(
        OUT / f"{split}.csv", index=False)
    print(split, len(items))

# --------------------------------------------------------------------------- local-only paper corpus
if not (ROOT / "design_thinking_merged.jsonl").exists():
    print("design_thinking_merged.jsonl not found; skipping paper corpus")
    raise SystemExit(0)
EMAIL = re.compile(r"\S+@\S+\.\S+")
seen, docs = set(), []
for line in open(ROOT / "design_thinking_merged.jsonl"):
    d = json.loads(line)
    h = hashlib.md5(d["content"].encode()).hexdigest()
    if h in seen:
        continue
    seen.add(h)
    text = d["content"]
    # flatten markdown tables (broken PDF conversions) into plain text
    out = []
    for ln in text.splitlines():
        if re.fullmatch(r"\s*\|?[\s\-:|]+\|?\s*", ln) and "-" in ln:
            continue
        if ln.strip().startswith("|"):
            ln = " ".join(c.strip() for c in ln.split("|") if c.strip())
        out.append(ln)
    text = EMAIL.sub("", "\n".join(out))
    text = re.sub(r"[ \t]{2,}", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    # cut reference sections
    text = re.split(r"\n\s*(REFERENCES|References|Bibliography)\s*\n", text)[0]
    # chunk ~1500 chars on paragraph boundaries
    buf = ""
    for para in text.split("\n\n"):
        if len(buf) + len(para) > 1500 and buf:
            docs.append({"source": d["file_name"], "text": buf.strip()})
            buf = ""
        buf += para + "\n\n"
    if buf.strip():
        docs.append({"source": d["file_name"], "text": buf.strip()})
with open(OUT / "papers_corpus.jsonl", "w") as fh:
    for d in docs:
        if len(d["text"]) > 200:
            fh.write(json.dumps(d, ensure_ascii=False) + "\n")
print("unique papers", len(seen), "chunks", len(docs))
