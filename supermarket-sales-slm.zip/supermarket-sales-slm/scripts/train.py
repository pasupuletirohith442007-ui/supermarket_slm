"""Fine-tune SmolLM2-135M-Instruct on the supermarket Q&A data (CPU friendly).

  .venv/bin/python scripts/train.py [--epochs 3] [--no-papers]

Q&A examples use the chat template with loss on the answer only.
Paper chunks (local only) are mixed in as plain language-modelling text.
"""
import argparse
import csv
import json
import math
import random
import time
from pathlib import Path

import torch
from torch.nn.utils.rnn import pad_sequence
from transformers import AutoModelForCausalLM, AutoTokenizer, get_cosine_schedule_with_warmup

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
BASE = "HuggingFaceTB/SmolLM2-135M-Instruct"
SYSTEM = "You are a retail analytics assistant for a supermarket chain with branches in Yangon, Mandalay and Naypyitaw."

ap = argparse.ArgumentParser()
ap.add_argument("--epochs", type=int, default=3)
ap.add_argument("--lr", type=float, default=1e-4)
ap.add_argument("--bs", type=int, default=16)
ap.add_argument("--no-papers", action="store_true")
ap.add_argument("--out", default=str(ROOT / "models" / "smollm2-135m-supermarket"))
args = ap.parse_args()

torch.manual_seed(0)
random.seed(0)
torch.set_num_threads(16)

tok = AutoTokenizer.from_pretrained(BASE)
model = AutoModelForCausalLM.from_pretrained(BASE, torch_dtype=torch.float32)
if tok.pad_token is None:
    tok.pad_token = tok.eos_token


def load(name):
    return list(csv.DictReader(open(DATA / f"{name}.csv", newline="", encoding="utf-8")))


def encode_qa(ex, max_len=320):
    prompt = tok.apply_chat_template(
        [{"role": "system", "content": SYSTEM}, {"role": "user", "content": ex["question"]}],
        tokenize=False, add_generation_prompt=True)
    p_ids = tok(prompt, add_special_tokens=False).input_ids
    a_ids = tok(ex["answer"] + tok.eos_token, add_special_tokens=False).input_ids
    ids = (p_ids + a_ids)[:max_len]
    labels = ([-100] * len(p_ids) + a_ids)[:max_len]
    return torch.tensor(ids), torch.tensor(labels)


def encode_text(text, max_len=384):
    ids = tok(text + tok.eos_token, add_special_tokens=False).input_ids[:max_len]
    t = torch.tensor(ids)
    return t, t.clone()


train_rows = load("train")
# facts have only 2 training paraphrases each -> repeat them so the numbers get memorised
FACT_REPEAT = 6
train = [encode_qa(e) for e in train_rows
         for _ in range(1 if e["category"] == "calculation" else FACT_REPEAT)]
if not args.no_papers and (DATA / "papers_corpus.jsonl").exists():
    papers = [encode_text(json.loads(l)["text"]) for l in open(DATA / "papers_corpus.jsonl")]
    print(f"mixing {len(papers)} paper chunks")
    train += papers
val = [encode_qa(e) for e in load("validation")]
print(f"train examples {len(train)}  validation {len(val)}")


def batches(data, bs, shuffle):
    idx = list(range(len(data)))
    if shuffle:
        random.shuffle(idx)
    # bucket by length to reduce padding
    chunks = [idx[i:i + bs * 20] for i in range(0, len(idx), bs * 20)]
    for ch in chunks:
        ch.sort(key=lambda i: len(data[i][0]))
        bl = [ch[i:i + bs] for i in range(0, len(ch), bs)]
        if shuffle:
            random.shuffle(bl)
        for b in bl:
            ids = pad_sequence([data[i][0] for i in b], batch_first=True, padding_value=tok.pad_token_id)
            lab = pad_sequence([data[i][1] for i in b], batch_first=True, padding_value=-100)
            att = pad_sequence([torch.ones(len(data[i][0]), dtype=torch.long) for i in b], batch_first=True)
            yield ids, att, lab


@torch.no_grad()
def evaluate():
    model.eval()
    tot, n = 0.0, 0
    for ids, att, lab in batches(val, 32, False):
        out = model(input_ids=ids, attention_mask=att, labels=lab)
        k = (lab[:, 1:] != -100).sum().item()
        tot += out.loss.item() * k
        n += k
    model.train()
    return tot / n


steps = math.ceil(len(train) / args.bs) * args.epochs
opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=0.01)
sched = get_cosine_schedule_with_warmup(opt, int(0.05 * steps), steps)
print(f"total steps {steps}; initial val loss {evaluate():.4f}", flush=True)

best = float("inf")
step, t0 = 0, time.time()
model.train()
for ep in range(args.epochs):
    for ids, att, lab in batches(train, args.bs, True):
        loss = model(input_ids=ids, attention_mask=att, labels=lab).loss
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step(); sched.step(); opt.zero_grad()
        step += 1
        if step % 25 == 0:
            el = time.time() - t0
            print(f"ep {ep+1} step {step}/{steps} loss {loss.item():.4f} "
                  f"elapsed {el/60:.1f}m eta {(steps-step)*el/step/60:.1f}m", flush=True)
    vl = evaluate()
    print(f"== epoch {ep+1} validation loss {vl:.4f} (ppl {math.exp(vl):.2f})", flush=True)
    if vl < best:
        best = vl
        model.save_pretrained(args.out)
        tok.save_pretrained(args.out)
        print(f"saved best model to {args.out}", flush=True)
print("done; best validation loss", best)
